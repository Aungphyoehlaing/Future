from django import forms
from django.contrib.auth.models import User
from myshop.models import categoryModel
from django.forms import widgets

class postForm(forms.Form):
    title = forms.CharField()
    body = forms.CharField()
    image = forms.ImageField()
    author = forms.ModelChoiceField(queryset=User.objects.all())
    category = forms.ModelChoiceField(queryset=categoryModel.objects.all())
    created_at = forms.DateTimeField()