from django.shortcuts import render, redirect
from myshop.models import postModel, categoryModel, commentModel, UserDetailModel
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, permission_required
from datetime import datetime
from django.core.paginator import Paginator
from django.db.models import Q



# Create your views here.
def to_home(request):
    return redirect('post_list')

# @permission_required('my_blog.view_postmodel', login_url='login')
def postList(request):
    posts = postModel.objects.all().order_by('-created_at')
    paginator = Paginator(posts, 3)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'postList.html',{'posts': page_obj})

@permission_required('myblog.add_postmodel', login_url='login')
def postCreate(request):
    if request.method == "GET":
        category = categoryModel.objects.all()
        return render(request, 'postCreate.html', {'category':category})
    if request.method == "POST":
        posts = postModel.objects.create(
            title = request.POST.get('title'),
            body = request.POST.get('body'),
            created_at = datetime.now(),
            image = request.FILES.get('image'),
            category_id = request.POST.get('category'),
            author_id = request.user.id,
        )
        posts.save()
        messages.success(request, "The post has been created successfully.")
        return redirect('post_list')
    else:
        messages.error(request, "Can't create, Something went wrong.")
        return redirect('post_list')

@permission_required('my_blog.view_postmodel', login_url='login')
def postDetail(request, post_id):
    cmt = commentModel.objects.filter(post_id = post_id)
    posts = postModel.objects.get(id=post_id)
    return render(request, 'postDetail.html',{'posts':posts,'cmt':cmt})

@permission_required('my_blog.change_postmodel', login_url='login')
def postUpdate(request,post_id):
    if request.method == "GET":
        category = categoryModel.objects.all()
        posts = postModel.objects.get(id=post_id)
        posts.created_at = posts.created_at.strftime('%Y-%m-%dT%H:%M')
        return render(request, "postUpdate.html", {"posts":posts, 'category':category})
    if request.method == "POST":
        posts = postModel.objects.get(id=post_id)
        posts.title = request.POST.get('title')
        posts.body = request.POST.get('body')
        posts.category_id = request.POST.get('category')
        posts.created_at = datetime.now()
        if request.FILES.get('image'):
            posts.image.delete()
            posts.image = request.FILES.get('image')
        posts.save()
        messages.info(request, "The post has been updated successfully.")
        return redirect('post_list')
    else:
            messages.error(request, "Can't update, Something went wrong.")
            return redirect('post_list')
     
@permission_required('my_blog.delete_postmodel', login_url='login')   
def postDelete(request, post_id):
    posts = postModel.objects.get(id=post_id)
    posts.image.delete()
    posts.delete()
    messages.info(request, "The post has been deleted successfully.")
    return redirect('post_list')

def cmtCreate(request, post_id):
    if request.method == "POST":
        cmt = commentModel.objects.create(
            content = request.POST.get('content'),
            author_id = request.user.id,
            post_id = post_id
        )
        cmt.save()
        return redirect(f'/blog/post/detail/{post_id}/#comment')

def cmtDelete(request, post_id, cmt_id):
    cmt = commentModel.objects.get(id=cmt_id)
    cmt.delete()
    return redirect(f'/blog/post/detail/{post_id}/#comment')

def cmtUpdate(request, post_id, cmt_id):
    if request.method == "GET":
        cmt = commentModel.objects.get(id=cmt_id)
        return render(request, 'cmtUpdate.html',{'cmt':cmt})
    if request.method == "POST":
        cmt = commentModel.objects.get(id=cmt_id)
        cmt.content = request.POST.get('content')
        cmt.save()
        return redirect(f'/blog/post/detail/{post_id}/#comment')

def login_view(request):
    if request.method == "GET":
        return render(request,'login.html')
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            messages.info(request, "Login successfully.")
            return redirect('post_list')
        else:
            messages.error(request, "Username or Password is incorrect!")
            return redirect('login')
        
def search_by(request):
    search = request.GET.get('search') 
    if search:
        posts = postModel.objects.filter( 
            Q(title__icontains=search) | 
            Q(body__icontains=search)
        )       
        return render(request, 'postList.html', {'posts': posts}) 
    else:
        posts = postModel.objects.all().order_by('-created_at') 
        return render(request, 'postList.html', {'posts': posts})

        
def logout_view(request):
    logout(request)
    return redirect('login')

def custom_404_view(request):
    return render(request, '404.html')

def user_view(requst, user_id):
    detail = UserDetailModel.objects.get(user_id = user_id)
    return render(requst, 'userDetail.html',{'detail':detail})

def user_update(request, user_id):
    if request.method == "GET":
        detail = UserDetailModel.objects.get(user_id = user_id)
        detail.birthday = detail.birthday.strftime('%Y-%m-%d')
        return render(request, 'userUpdate.html',{'detail':detail})
    if request.method == "POST":
        try:
            detail = UserDetailModel.objects.get(user_id = user_id)
            detail.address = request.POST.get('address')
            detail.phone = request.POST.get('phone')
            detail.birthday = request.POST.get('birthday')
            detail.save()
            users = User.objects.get(id = user_id)
            users.username = request.POST.get('username')
            users.email = request.POST.get('email')
            users.save()
            messages.info(request, "User Update Success")
            return redirect('/blog/post/list')
        except Exception as e:
            messages.error(request, e)
            return redirect('/blog/post/list')

def contact(request):
    return render(request, 'contact.html')

def flight(request):
    return render(request, 'flight.html')
