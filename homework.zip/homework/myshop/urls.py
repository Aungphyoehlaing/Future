from django.urls import path 
from myshop import views

urlpatterns = [
    path('post/list/', views.postList, name="post_list"),
    path('post/create/', views.postCreate, name="post_create"),
    path('post/detail/<int:post_id>/', views.postDetail),
    path('post/update/<int:post_id>/', views.postUpdate),
    path('post/delete/<int:post_id>/', views.postDelete),
    path('cmt/create/<int:post_id>/', views.cmtCreate),
    path('cmt/delete/<int:post_id>/<int:cmt_id>/', views.cmtDelete),
    path('cmt/update/<int:post_id>/<int:cmt_id>/', views.cmtUpdate),
    path('search_by/', views.search_by),
    path('user/<int:user_id>/', views.user_view, name="userdetail"),
    path('user/update/<int:user_id>/', views.user_update),
    path('contact/', views.contact, name="contact"),
    path('flight/', views.flight, name="flight"),
]